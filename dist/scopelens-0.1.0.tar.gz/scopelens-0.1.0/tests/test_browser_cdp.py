import json
import urllib.error
import websocket
import pytest

from scopelens.browser_cdp import (
    send_cdp_command,
    build_browser_context,
    discover_page_targets
)


def test_discover_page_targets(monkeypatch):
    response_data = [
        {
            "id": "page-1",
            "type": "page",
            "title": "Login",
            "url": "https://example.com/login",
            "webSocketDebuggerUrl": "ws://localhost/devtools/page/page-1",
        },
        {
            "id": "worker-1",
            "type": "service_worker",
            "title": "Worker",
            "url": "https://example.com/sw.js",
            "webSocketDebuggerUrl": "ws://localhost/devtools/page/worker-1",
        },
    ]

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            pass

        def read(self):
            return json.dumps(response_data).encode("utf-8")

        def close(self):
            pass

    def fake_urlopen(url):
        return FakeResponse()

    monkeypatch.setattr(
        "urllib.request.urlopen",
        fake_urlopen,
    )

    targets = discover_page_targets(
        "http://localhost:9222",
    )

    assert targets == [
        {
            "id": "page-1",
            "title": "Login",
            "url": "https://example.com/login",
            "websocket_url": "ws://localhost/devtools/page/page-1",
        }
    ]

def test_discover_page_targets_raises_connection_error(monkeypatch):
    def fake_urlopen(url):
        raise urllib.error.URLError("connection refused")

    monkeypatch.setattr(
        "urllib.request.urlopen",
        fake_urlopen,
    )

    with pytest.raises(
        ConnectionError,
        match="Unable to connect to Chrome debugging endpoint",
    ):
        discover_page_targets(
            "http://localhost:9222",
        )

def test_discover_page_targets_raises_invalid_response_error(monkeypatch):
    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            pass

        def read(self):
            return b"not-json"

        def close(self):
            pass

    def fake_urlopen(url):
        return FakeResponse()

    monkeypatch.setattr(
        "urllib.request.urlopen",
        fake_urlopen,
    )

    with pytest.raises(
        ValueError,
        match="Invalid response from Chrome debugging endpoint",
    ):
        discover_page_targets(
            "http://localhost:9222",
        )

def test_send_cdp_command_returns_matching_result(monkeypatch):
    class FakeWebSocket:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            pass

        def send(self, payload):
            self.sent_payload = json.loads(payload)

        def recv(self):
            return json.dumps(
                {
                    "id": 1,
                    "result": {
                        "value": "Login",
                    },
                }
            )

        def close(self):
            pass

    def fake_create_connection(url):
        return FakeWebSocket()

    monkeypatch.setattr(
        "scopelens.browser_cdp.websocket.create_connection",
        fake_create_connection,
    )

    result = send_cdp_command(
        websocket_url="ws://localhost/devtools/page/page-1",
        method="Runtime.evaluate",
        params={
            "expression": "document.title",
        },
    )

    assert result == {
        "value": "Login",
    }

def test_send_cdp_command_raises_runtime_error(monkeypatch):
    class FakeWebSocket:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            pass

        def send(self, payload):
            pass

        def recv(self):
            return json.dumps(
                {
                    "id": 1,
                    "error": {
                        "code": -32000,
                        "message": "Command failed",
                    },
                }
            )

        def close(self):
            pass

    def fake_create_connection(url):
        return FakeWebSocket()

    monkeypatch.setattr(
        "scopelens.browser_cdp.websocket.create_connection",
        fake_create_connection,
    )

    with pytest.raises(RuntimeError):
        send_cdp_command(
            websocket_url="ws://localhost/devtools/page/page-1",
            method="Runtime.evaluate",
        )

def test_send_cdp_command_ignores_unrelated_messages(monkeypatch):
    class FakeWebSocket:
        def __init__(self):
            self.messages = iter(
                [
                    json.dumps(
                        {
                            "method": "Runtime.consoleAPICalled",
                            "params": {},
                        }
                    ),
                    json.dumps(
                        {
                            "id": 99,
                            "result": {
                                "value": "wrong",
                            },
                        }
                    ),
                    json.dumps(
                        {
                            "id": 1,
                            "result": {
                                "value": "Login",
                            },
                        }
                    ),
                ]
            )

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            pass

        def send(self, payload):
            pass

        def recv(self):
            return next(self.messages)

        def close(self):
            pass

    def fake_create_connection(url):
        return FakeWebSocket()

    monkeypatch.setattr(
        "scopelens.browser_cdp.websocket.create_connection",
        fake_create_connection,
    )

    result = send_cdp_command(
        websocket_url="ws://localhost/devtools/page/page-1",
        method="Runtime.evaluate",
    )

    assert result == {
        "value": "Login",
    }

def test_send_cdp_command_raises_invalid_response_error(monkeypatch):
    class FakeWebSocket:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            pass

        def send(self, payload):
            pass

        def recv(self):
            return "not-json"

        def close(self):
            pass

    def fake_create_connection(url):
        return FakeWebSocket()

    monkeypatch.setattr(
        "scopelens.browser_cdp.websocket.create_connection",
        fake_create_connection,
    )

    with pytest.raises(
        ValueError,
        match="Invalid response from Chrome DevTools Protocol",
    ):
        send_cdp_command(
            websocket_url="ws://localhost/devtools/page/page-1",
            method="Runtime.evaluate",
        )

def test_send_cdp_command_raises_connection_error(monkeypatch):
    def fake_create_connection(url):
        raise OSError("connection refused")

    monkeypatch.setattr(
        "scopelens.browser_cdp.websocket.create_connection",
        fake_create_connection,
    )

    with pytest.raises(
        ConnectionError,
        match="Unable to connect to Chrome DevTools Protocol",
    ):
        send_cdp_command(
            websocket_url="ws://localhost/devtools/page/page-1",
            method="Runtime.evaluate",
        )

def test_evaluate_expression_returns_value(monkeypatch):
    def fake_send_cdp_command(
        websocket_url,
        method,
        params=None,
    ):
        assert method == "Runtime.evaluate"
        assert params == {
            "expression": "document.title",
            "returnByValue": True,
        }

        return {
            "result": {
                "type": "string",
                "value": "Login",
            }
        }

    monkeypatch.setattr(
        "scopelens.browser_cdp.send_cdp_command",
        fake_send_cdp_command,
    )

    from scopelens.browser_cdp import evaluate_expression

    result = evaluate_expression(
        websocket_url="ws://localhost/devtools/page/page-1",
        expression="document.title",
    )

    assert result == "Login"

def test_get_page_html_returns_document_html(monkeypatch):
    def fake_evaluate_expression(
        websocket_url,
        expression,
    ):
        assert expression == "document.documentElement.outerHTML"
        return "<html><body>Login</body></html>"

    monkeypatch.setattr(
        "scopelens.browser_cdp.evaluate_expression",
        fake_evaluate_expression,
    )

    from scopelens.browser_cdp import get_page_html

    html = get_page_html(
        websocket_url="ws://localhost/devtools/page/page-1",
    )

    assert html == "<html><body>Login</body></html>"

def test_inspect_page_returns_browser_facts(monkeypatch):
    html = """
    <html>
        <head>
            <title>Login</title>
        </head>
        <body>
            <h1>Sign In</h1>
            <input id="username" name="username">
            <button id="login-button">Login</button>
        </body>
    </html>
    """

    monkeypatch.setattr(
        "scopelens.browser_cdp.get_page_html",
        lambda websocket_url: html,
    )

    from scopelens.browser_cdp import inspect_page

    facts = inspect_page(
        websocket_url="ws://localhost/devtools/page/page-1",
        url="https://example.com/login",
    )

    assert facts["url"] == "https://example.com/login"
    assert facts["title"] == "Login"
    assert facts["headings"] == ["Sign In"]
    assert facts["contains_testable_elements"] is True

def test_inspect_first_page_discovers_and_inspects_target(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.discover_page_targets",
        lambda debugger_url: [
            {
                "id": "page-1",
                "title": "Login",
                "url": "https://example.com/login",
                "websocket_url": "ws://localhost/devtools/page/page-1",
            }
        ],
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.inspect_page",
        lambda websocket_url, url: {
            "url": url,
            "title": "Login",
            "contains_testable_elements": True,
        },
    )

    from scopelens.browser_cdp import inspect_first_page

    facts = inspect_first_page(
        debugger_url="http://localhost:9222",
    )

    assert facts == {
        "url": "https://example.com/login",
        "title": "Login",
        "contains_testable_elements": True,
    }

def test_inspect_first_page_raises_when_no_targets(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.discover_page_targets",
        lambda debugger_url: [],
    )

    from scopelens.browser_cdp import inspect_first_page

    with pytest.raises(
        RuntimeError,
        match="No Chrome page targets available",
    ):
        inspect_first_page(
            debugger_url="http://localhost:9222",
        )

def test_inspect_first_page_skips_targets_without_websocket_url(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.discover_page_targets",
        lambda debugger_url: [
            {
                "id": "page-1",
                "title": "Unusable",
                "url": "https://example.com/one",
                "websocket_url": None,
            },
            {
                "id": "page-2",
                "title": "Login",
                "url": "https://example.com/login",
                "websocket_url": "ws://localhost/devtools/page/page-2",
            },
        ],
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.inspect_page",
        lambda websocket_url, url: {
            "url": url,
            "title": "Login",
        },
    )

    from scopelens.browser_cdp import inspect_first_page

    facts = inspect_first_page(
        debugger_url="http://localhost:9222",
    )

    assert facts["url"] == "https://example.com/login"

def test_inspect_first_page_raises_when_no_usable_targets(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.discover_page_targets",
        lambda debugger_url: [
            {
                "id": "page-1",
                "title": "One",
                "url": "https://example.com/one",
                "websocket_url": None,
            },
            {
                "id": "page-2",
                "title": "Two",
                "url": "https://example.com/two",
                "websocket_url": None,
            },
        ],
    )

    from scopelens.browser_cdp import inspect_first_page

    with pytest.raises(
        RuntimeError,
        match="No usable Chrome page targets available",
    ):
        inspect_first_page(
            debugger_url="http://localhost:9222",
        )

def test_inspect_pages_returns_facts_for_all_usable_targets(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.discover_page_targets",
        lambda debugger_url: [
            {
                "id": "page-1",
                "title": "Login",
                "url": "https://example.com/login",
                "websocket_url": "ws://localhost/devtools/page/page-1",
            },
            {
                "id": "page-2",
                "title": "Account",
                "url": "https://example.com/account",
                "websocket_url": "ws://localhost/devtools/page/page-2",
            },
            {
                "id": "page-3",
                "title": "Unusable",
                "url": "https://example.com/unused",
                "websocket_url": None,
            },
        ],
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.inspect_page",
        lambda websocket_url, url: {
            "url": url,
        },
    )

    from scopelens.browser_cdp import inspect_pages

    pages = inspect_pages(
        debugger_url="http://localhost:9222",
    )

    assert pages == [
        {
            "url": "https://example.com/login",
        },
        {
            "url": "https://example.com/account",
        },
    ]

def test_inspect_pages_respects_max_pages(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.discover_page_targets",
        lambda debugger_url: [
            {
                "id": "page-1",
                "url": "https://example.com/one",
                "websocket_url": "ws://localhost/page-1",
            },
            {
                "id": "page-2",
                "url": "https://example.com/two",
                "websocket_url": "ws://localhost/page-2",
            },
            {
                "id": "page-3",
                "url": "https://example.com/three",
                "websocket_url": "ws://localhost/page-3",
            },
        ],
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.inspect_page",
        lambda websocket_url, url: {
            "url": url,
        },
    )

    from scopelens.browser_cdp import inspect_pages

    pages = inspect_pages(
        debugger_url="http://localhost:9222",
        max_pages=2,
    )

    assert pages == [
        {"url": "https://example.com/one"},
        {"url": "https://example.com/two"},
    ]

def test_inspect_pages_rejects_non_positive_max_pages():
    from scopelens.browser_cdp import inspect_pages

    with pytest.raises(
        ValueError,
        match="max_pages must be greater than zero",
    ):
        inspect_pages(
            debugger_url="http://localhost:9222",
            max_pages=0,
        )

def test_inspect_pages_returns_empty_list_when_no_usable_targets(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.discover_page_targets",
        lambda debugger_url: [
            {
                "id": "page-1",
                "url": "https://example.com/one",
                "websocket_url": None,
            }
        ],
    )

    from scopelens.browser_cdp import inspect_pages

    pages = inspect_pages(
        debugger_url="http://localhost:9222",
    )

    assert pages == []

def test_navigate_page_sends_page_navigate(monkeypatch):
    captured = {}

    def fake_send_cdp_command(
        websocket_url,
        method,
        params=None,
    ):
        captured["websocket_url"] = websocket_url
        captured["method"] = method
        captured["params"] = params

        return {
            "frameId": "frame-1",
        }

    monkeypatch.setattr(
        "scopelens.browser_cdp.send_cdp_command",
        fake_send_cdp_command,
    )

    from scopelens.browser_cdp import navigate_page

    result = navigate_page(
        websocket_url="ws://localhost/devtools/page/page-1",
        url="https://example.com/account",
    )

    assert captured == {
        "websocket_url": "ws://localhost/devtools/page/page-1",
        "method": "Page.navigate",
        "params": {
            "url": "https://example.com/account",
        },
    }

    assert result == {
        "frameId": "frame-1",
    }

def test_wait_for_page_load_waits_for_load_event(monkeypatch):
    class FakeWebSocket:
        def __init__(self):
            self.messages = iter(
                [
                    json.dumps(
                        {
                            "method": "Page.frameNavigated",
                            "params": {},
                        }
                    ),
                    json.dumps(
                        {
                            "method": "Page.loadEventFired",
                            "params": {},
                        }
                    ),
                ]
            )

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            pass

        def send(self, payload):
            pass

        def recv(self):
            return next(self.messages)

        def close(self):
            pass

    monkeypatch.setattr(
        "scopelens.browser_cdp.websocket.create_connection",
        lambda url, timeout=None: FakeWebSocket(),
    )

    from scopelens.browser_cdp import wait_for_page_load

    wait_for_page_load(
        websocket_url="ws://localhost/devtools/page/page-1",
    )

def test_wait_for_page_load_raises_timeout(monkeypatch):
    class FakeWebSocket:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            pass

        def recv(self):
            raise websocket.WebSocketTimeoutException(
                "timed out"
            )

        def close(self):
            pass

    monkeypatch.setattr(
        "scopelens.browser_cdp.websocket.create_connection",
        lambda url, timeout=None: FakeWebSocket(),
    )

    from scopelens.browser_cdp import wait_for_page_load

    with pytest.raises(
        TimeoutError,
        match="Timed out waiting for page load",
    ):
        wait_for_page_load(
            websocket_url="ws://localhost/devtools/page/page-1",
            timeout=5,
        )

def test_navigate_and_inspect_runs_full_flow(monkeypatch):
    calls = []

    monkeypatch.setattr(
        "scopelens.browser_cdp.navigate_page",
        lambda websocket_url, url: calls.append(
            ("navigate", websocket_url, url)
        ),
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.wait_for_document_ready",
        lambda websocket_url, timeout=10: calls.append(
            ("wait", websocket_url, timeout)
        ),
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.inspect_page",
        lambda websocket_url, url: {
            "url": url,
            "title": "Account",
        },
    )

    from scopelens.browser_cdp import navigate_and_inspect

    facts = navigate_and_inspect(
        websocket_url="ws://localhost/devtools/page/page-1",
        url="https://example.com/account",
        timeout=5,
    )

    assert calls == [
        (
            "navigate",
            "ws://localhost/devtools/page/page-1",
            "https://example.com/account",
        ),
        (
            "wait",
            "ws://localhost/devtools/page/page-1",
            5,
        ),
    ]

    assert facts == {
        "url": "https://example.com/account",
        "title": "Account",
    }

def test_traverse_pages_respects_max_pages(monkeypatch):
    inspected = []

    def fake_navigate_and_inspect(
        websocket_url,
        url,
        timeout=10,
    ):
        inspected.append(url)

        pages = {
            "https://example.com/": {
                "url": "https://example.com/",
                "navigable_links": [
                    "https://example.com/account",
                    "https://example.com/settings",
                ],
            },
            "https://example.com/account": {
                "url": "https://example.com/account",
                "navigable_links": [],
            },
            "https://example.com/settings": {
                "url": "https://example.com/settings",
                "navigable_links": [],
            },
        }

        return pages[url]

    monkeypatch.setattr(
        "scopelens.browser_cdp.navigate_and_inspect",
        fake_navigate_and_inspect,
    )

    from scopelens.browser_cdp import traverse_pages

    pages = traverse_pages(
        websocket_url="ws://localhost/devtools/page/page-1",
        start_url="https://example.com/",
        max_pages=2,
    )

    assert inspected == [
        "https://example.com/",
        "https://example.com/account",
    ]

    assert len(pages) == 2

def test_traverse_pages_does_not_revisit_urls(monkeypatch):
    inspected = []

    def fake_navigate_and_inspect(
        websocket_url,
        url,
        timeout=10,
    ):
        inspected.append(url)

        pages = {
            "https://example.com/": {
                "url": "https://example.com/",
                "navigable_links": [
                    "https://example.com/account",
                ],
            },
            "https://example.com/account": {
                "url": "https://example.com/account",
                "navigable_links": [
                    "https://example.com/",
                ],
            },
        }

        return pages[url]

    monkeypatch.setattr(
        "scopelens.browser_cdp.navigate_and_inspect",
        fake_navigate_and_inspect,
    )

    from scopelens.browser_cdp import traverse_pages

    pages = traverse_pages(
        websocket_url="ws://localhost/devtools/page/page-1",
        start_url="https://example.com/",
        max_pages=10,
    )

    assert inspected == [
        "https://example.com/",
        "https://example.com/account",
    ]

    assert len(pages) == 2

def test_traverse_pages_respects_max_depth(monkeypatch):
    inspected = []

    def fake_navigate_and_inspect(
        websocket_url,
        url,
        timeout=10,
    ):
        inspected.append(url)

        pages = {
            "https://example.com/": {
                "url": "https://example.com/",
                "navigable_links": [
                    "https://example.com/account",
                ],
            },
            "https://example.com/account": {
                "url": "https://example.com/account",
                "navigable_links": [
                    "https://example.com/account/details",
                ],
            },
            "https://example.com/account/details": {
                "url": "https://example.com/account/details",
                "navigable_links": [],
            },
        }

        return pages[url]

    monkeypatch.setattr(
        "scopelens.browser_cdp.navigate_and_inspect",
        fake_navigate_and_inspect,
    )

    from scopelens.browser_cdp import traverse_pages

    pages = traverse_pages(
        websocket_url="ws://localhost/devtools/page/page-1",
        start_url="https://example.com/",
        max_pages=10,
        max_depth=1,
    )

    assert inspected == [
        "https://example.com/",
        "https://example.com/account",
    ]

    assert len(pages) == 2

def test_traverse_pages_rejects_negative_max_depth():
    from scopelens.browser_cdp import traverse_pages

    with pytest.raises(
        ValueError,
        match="max_depth must be zero or greater",
    ):
        traverse_pages(
            websocket_url="ws://localhost/devtools/page/page-1",
            start_url="https://example.com/",
            max_depth=-1,
        )

def test_traverse_first_page_discovers_target_and_traverses(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.discover_page_targets",
        lambda debugger_url: [
            {
                "id": "page-1",
                "title": "Home",
                "url": "https://example.com/",
                "websocket_url": "ws://localhost/devtools/page/page-1",
            }
        ],
    )

    captured = {}

    def fake_traverse_pages(
        websocket_url,
        start_url,
        max_pages=10,
        max_depth=1,
        timeout=10,
    ):
        captured["websocket_url"] = websocket_url
        captured["start_url"] = start_url
        captured["max_pages"] = max_pages
        captured["max_depth"] = max_depth
        captured["timeout"] = timeout

        return [
            {
                "url": start_url,
                "title": "Home",
            }
        ]

    monkeypatch.setattr(
        "scopelens.browser_cdp.traverse_pages",
        fake_traverse_pages,
    )

    from scopelens.browser_cdp import traverse_first_page

    pages = traverse_first_page(
        debugger_url="http://localhost:9222",
        max_pages=5,
        max_depth=2,
        timeout=7,
    )

    assert captured == {
        "websocket_url": "ws://localhost/devtools/page/page-1",
        "start_url": "https://example.com/",
        "max_pages": 5,
        "max_depth": 2,
        "timeout": 7,
    }

    assert pages == [
        {
            "url": "https://example.com/",
            "title": "Home",
        }
    ]

def test_traverse_first_page_raises_when_no_usable_target(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.discover_page_targets",
        lambda debugger_url: [
            {
                "id": "page-1",
                "title": "Home",
                "url": "https://example.com/",
                "websocket_url": None,
            }
        ],
    )

    from scopelens.browser_cdp import traverse_first_page

    with pytest.raises(
        RuntimeError,
        match="No usable Chrome page targets available",
    ):
        traverse_first_page(
            debugger_url="http://localhost:9222",
        )

def test_traverse_first_page_rejects_invalid_bounds():
    from scopelens.browser_cdp import traverse_first_page

    with pytest.raises(
        ValueError,
        match="max_pages must be greater than zero",
    ):
        traverse_first_page(
            debugger_url="http://localhost:9222",
            max_pages=0,
        )

    with pytest.raises(
        ValueError,
        match="max_depth must be zero or greater",
    ):
        traverse_first_page(
            debugger_url="http://localhost:9222",
            max_depth=-1,
        )

def test_build_browser_context_packages_traversal_result():
    from scopelens.browser_cdp import build_browser_context

    pages = [
        {
            "url": "https://example.com/",
            "title": "Home",
            "navigable_links": [
                "https://example.com/account",
            ],
            "testable_elements": [],
        },
        {
            "url": "https://example.com/account",
            "title": "Account",
            "navigable_links": [],
            "testable_elements": [
                {
                    "tag": "button",
                    "selectors": [
                        "#save-button",
                    ],
                }
            ],
        },
    ]

    context = build_browser_context(
        start_url="https://example.com/",
        pages=pages,
    )

    assert context == {
        "target_type": "browser",
        "start_url": "https://example.com/",
        "page_count": 2,
        "pages": pages,
    }

def test_interrogate_browser_builds_context(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.traverse_first_page",
        lambda debugger_url, max_pages=10, max_depth=1, timeout=10: [
            {
                "url": "https://example.com/",
                "title": "Home",
            },
            {
                "url": "https://example.com/account",
                "title": "Account",
            },
        ],
    )

    from scopelens.browser_cdp import interrogate_browser

    context = interrogate_browser(
        debugger_url="http://localhost:9222",
        start_url="https://example.com/",
        max_pages=5,
        max_depth=2,
        timeout=7,
    )

    assert context == {
        "target_type": "browser",
        "start_url": "https://example.com/",
        "page_count": 2,
        "pages": [
            {
                "url": "https://example.com/",
                "title": "Home",
            },
            {
                "url": "https://example.com/account",
                "title": "Account",
            },
        ],
    }

def test_interrogate_browser_uses_first_page_url_when_start_url_missing(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.traverse_first_page",
        lambda debugger_url, max_pages=10, max_depth=1, timeout=10: [
            {
                "url": "https://example.com/",
                "title": "Home",
            }
        ],
    )

    from scopelens.browser_cdp import interrogate_browser

    context = interrogate_browser(
        debugger_url="http://localhost:9222",
    )

    assert context["start_url"] == "https://example.com/"

def test_interrogate_browser_handles_empty_traversal(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.traverse_first_page",
        lambda debugger_url, max_pages=10, max_depth=1, timeout=10: [],
    )

    from scopelens.browser_cdp import interrogate_browser

    context = interrogate_browser(
        debugger_url="http://localhost:9222",
    )

    assert context == {
        "target_type": "browser",
        "start_url": None,
        "page_count": 0,
        "pages": [],
    }

def test_browser_context_is_json_serializable():
    context = build_browser_context(
        start_url="https://example.com/",
        pages=[
            {
                "url": "https://example.com/",
                "title": "Home",
                "testable_elements": [
                    {
                        "tag": "button",
                        "selectors": [
                            "#save",
                        ],
                    }
                ],
            }
        ],
    )

    serialized = json.dumps(context)

    assert '"target_type": "browser"' in serialized
    assert '"page_count": 1' in serialized

def test_wait_for_document_ready(monkeypatch):
    states = iter([
        "loading",
        "interactive",
        "complete",
    ])

    monkeypatch.setattr(
        "scopelens.browser_cdp.evaluate_expression",
        lambda websocket_url, expression: next(states),
    )

    from scopelens.browser_cdp import wait_for_document_ready

    wait_for_document_ready(
        websocket_url="ws://chrome/page/1",
        timeout=1,
        poll_interval=0,
    )

def test_wait_for_document_ready_times_out(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.evaluate_expression",
        lambda websocket_url, expression: "loading",
    )

    from scopelens.browser_cdp import wait_for_document_ready

    with pytest.raises(
        TimeoutError,
        match="Timed out waiting for document readiness",
    ):
        wait_for_document_ready(
            websocket_url="ws://chrome/page/1",
            timeout=0,
            poll_interval=0,
        )

def test_send_cdp_command_closes_connection(monkeypatch):
    closed = {"value": False}

    class FakeWebSocket:
        def send(self, payload):
            pass

        def recv(self):
            return json.dumps(
                {
                    "id": 1,
                    "result": {
                        "value": "ok",
                    },
                }
            )

        def close(self):
            closed["value"] = True

    monkeypatch.setattr(
        "scopelens.browser_cdp.websocket.create_connection",
        lambda url: FakeWebSocket(),
    )

    from scopelens.browser_cdp import send_cdp_command

    send_cdp_command(
        websocket_url="ws://chrome/page/1",
        method="Runtime.evaluate",
    )

    assert closed["value"] is True

def test_set_input_value_uses_runtime_evaluate(monkeypatch):
    calls = []

    monkeypatch.setattr(
        "scopelens.browser_cdp.evaluate_expression",
        lambda websocket_url, expression: calls.append(
            (websocket_url, expression)
        ),
    )

    from scopelens.browser_cdp import set_input_value

    set_input_value(
        websocket_url="ws://chrome/page/1",
        selector="#username",
        value="maggie",
    )

    assert len(calls) == 1
    assert "#username" in calls[0][1]
    assert "maggie" in calls[0][1]

def test_inspect_pages_returns_facts_for_all_usable_targets(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.discover_page_targets",
        lambda debugger_url: [
            {
                "id": "page-1",
                "title": "Login",
                "url": "https://example.com/login",
                "websocket_url": "ws://localhost/devtools/page/page-1",
            },
            {
                "id": "page-2",
                "title": "Account",
                "url": "https://example.com/account",
                "websocket_url": "ws://localhost/devtools/page/page-2",
            },
            {
                "id": "page-3",
                "title": "Unusable",
                "url": "https://example.com/unused",
                "websocket_url": None,
            },
        ],
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.inspect_page",
        lambda websocket_url, url: {
            "url": url,
        },
    )

    from scopelens.browser_cdp import inspect_pages

    pages = inspect_pages(
        debugger_url="http://localhost:9222",
    )

    assert pages == [
        {
            "url": "https://example.com/login",
        },
        {
            "url": "https://example.com/account",
        },
    ]

def test_click_element_uses_runtime_evaluate(monkeypatch):
    calls = []

    monkeypatch.setattr(
        "scopelens.browser_cdp.evaluate_expression",
        lambda websocket_url, expression: calls.append(
            (websocket_url, expression)
        ),
    )

    from scopelens.browser_cdp import click_element

    click_element(
        websocket_url="ws://chrome/page/1",
        selector="#login",
    )

    assert len(calls) == 1
    assert "#login" in calls[0][1]
    assert ".click()" in calls[0][1]

def test_login_with_credentials_fills_and_submits(monkeypatch):
    calls = []

    monkeypatch.setattr(
        "scopelens.browser_cdp.set_input_value",
        lambda websocket_url, selector, value: calls.append(
            ("set", selector, value)
        ),
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.click_element",
        lambda websocket_url, selector: calls.append(
            ("click", selector)
        ),
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.wait_for_document_ready",
        lambda websocket_url, timeout=10: calls.append(
            ("wait", timeout)
        ),
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.get_current_url",
        lambda websocket_url: "https://example.com/login",
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.wait_for_url_change",
        lambda websocket_url, original_url, timeout=10: calls.append(
            ("url_change", original_url, timeout)
        ),
    )

    from scopelens.browser_cdp import login_with_credentials

    login_with_credentials(
        websocket_url="ws://chrome/page/1",
        username_selector="#username",
        username="maggie",
        password_selector="#password",
        password="secret",
        submit_selector="#login",
        timeout=5,
    )

    assert calls == [
        ("set", "#username", "maggie"),
        ("set", "#password", "secret"),
        ("click", "#login"),
        ("url_change", "https://example.com/login", 5),
        ("wait", 5),
    ]

def test_login_credentials_are_not_returned_in_context(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.traverse_first_page",
        lambda debugger_url, max_pages=10, max_depth=1, timeout=10: [
            {
                "url": "https://example.com/dashboard",
                "title": "Dashboard",
            }
        ],
    )

    from scopelens.browser_cdp import interrogate_browser

    context = interrogate_browser(
        debugger_url="http://localhost:9222",
        start_url="https://example.com/login",
        max_pages=1,
        max_depth=0,
    )

    serialized = json.dumps(context)

    assert "maggie" not in serialized
    assert "secret" not in serialized

def test_interrogate_browser_can_login_before_traversal(monkeypatch):
    calls = []

    monkeypatch.setattr(
        "scopelens.browser_cdp.discover_page_targets",
        lambda debugger_url: [
            {
                "id": "page-1",
                "title": "Login",
                "url": "https://example.com/login",
                "websocket_url": "ws://chrome/page/1",
            }
        ],
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.login_with_credentials",
        lambda websocket_url,
               username_selector,
               username,
               password_selector,
               password,
               submit_selector,
               timeout=10: calls.append(
            (
                websocket_url,
                username_selector,
                username,
                password_selector,
                password,
                submit_selector,
                timeout,
            )
        ),
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.traverse_pages",
        lambda websocket_url,
               start_url,
               max_pages=10,
               max_depth=1,
               timeout=10: [
            {
                "url": "https://example.com/dashboard",
                "title": "Dashboard",
            }
        ],
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.get_current_url",
        lambda websocket_url: "https://example.com/dashboard",
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.navigate_and_inspect",
        lambda websocket_url, url, timeout=10: {
            "url": url,
        },
    )

    from scopelens.browser_cdp import interrogate_browser

    context = interrogate_browser(
        debugger_url="http://localhost:9222",
        start_url="https://example.com/login",
        username_selector="#username",
        username="maggie",
        password_selector="#password",
        password="secret",
        submit_selector="#login",
        max_pages=1,
        max_depth=0,
        timeout=5,
    )

    assert calls == [
        (
            "ws://chrome/page/1",
            "#username",
            "maggie",
            "#password",
            "secret",
            "#login",
            5,
        )
    ]

    assert context["page_count"] == 1
    assert context["pages"][0]["title"] == "Dashboard"

def test_interrogate_browser_rejects_partial_credentials():
    from scopelens.browser_cdp import interrogate_browser

    with pytest.raises(
        ValueError,
        match="Incomplete browser authentication configuration",
    ):
        interrogate_browser(
            debugger_url="http://localhost:9222",
            username_selector="#username",
            username="maggie",
        )

def test_get_current_url_uses_runtime_evaluate(monkeypatch):
    monkeypatch.setattr(
        "scopelens.browser_cdp.evaluate_expression",
        lambda websocket_url, expression: "http://localhost:8080/dashboard.html",
    )

    from scopelens.browser_cdp import get_current_url

    url = get_current_url(
        websocket_url="ws://chrome/page/1",
    )

    assert url == "http://localhost:8080/dashboard.html"

def test_wait_for_url_change(monkeypatch):
    urls = iter([
        "http://localhost:8080/login.html",
        "http://localhost:8080/login.html",
        "http://localhost:8080/dashboard.html",
    ])

    monkeypatch.setattr(
        "scopelens.browser_cdp.get_current_url",
        lambda websocket_url: next(urls),
    )

    from scopelens.browser_cdp import wait_for_url_change

    url = wait_for_url_change(
        websocket_url="ws://chrome/page/1",
        original_url="http://localhost:8080/login.html",
        timeout=1,
        poll_interval=0,
    )

    assert url == "http://localhost:8080/dashboard.html"

def test_interrogate_browser_navigates_to_login_url_before_auth(monkeypatch):
    calls = []

    monkeypatch.setattr(
        "scopelens.browser_cdp.discover_page_targets",
        lambda debugger_url: [
            {
                "id": "page-1",
                "title": "Home",
                "url": "http://localhost:8080/",
                "websocket_url": "ws://chrome/page/1",
            }
        ],
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.navigate_and_inspect",
        lambda websocket_url, url, timeout=10: calls.append(
            ("navigate", url, timeout)
        ) or {
            "url": url,
        },
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.login_with_credentials",
        lambda websocket_url,
               username_selector,
               username,
               password_selector,
               password,
               submit_selector,
               timeout=10: calls.append(
            ("login", websocket_url)
        ),
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.get_current_url",
        lambda websocket_url: "http://localhost:8080/dashboard.html",
    )

    monkeypatch.setattr(
        "scopelens.browser_cdp.traverse_pages",
        lambda websocket_url,
               start_url,
               max_pages=10,
               max_depth=1,
               timeout=10: [],
    )

    from scopelens.browser_cdp import interrogate_browser

    interrogate_browser(
        debugger_url="http://localhost:9222",
        start_url="http://localhost:8080/login.html",
        username_selector="#username",
        username="maggie",
        password_selector="#password",
        password="secret",
        submit_selector="#login",
        max_pages=1,
        max_depth=0,
        timeout=5,
    )

    assert calls[0] == (
        "navigate",
        "http://localhost:8080/login.html",
        5,
    )

    assert calls[1] == (
        "login",
        "ws://chrome/page/1",
    )