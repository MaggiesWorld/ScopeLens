from scopelens.browser_facts import extract_browser_facts


def test_extract_browser_facts_from_html():
    html = """
    <html>
        <head>
            <title>Login</title>
        </head>
        <body>
            <h1>Welcome</h1>

            <form id="login-form">
                <input id="username" name="username" type="text" />
                <input id="password" name="password" type="password" />
                <button id="login-button" type="submit">Login</button>
            </form>

            <a href="/forgot-password">Forgot password?</a>
        </body>
    </html>
    """

    facts = extract_browser_facts(
        html=html,
        url="https://example.com/login",
    )

    assert facts["url"] == "https://example.com/login"
    assert facts["title"] == "Login"
    assert facts["headings"] == [
        "Welcome",
    ]
    assert facts["buttons"] == [
        {
            "text": "Login",
            "id": "login-button",
            "type": "submit",
        }
    ]
    assert facts["inputs"] == [
        {
            "id": "username",
            "name": "username",
            "type": "text",
        },
        {
            "id": "password",
            "name": "password",
            "type": "password",
        },
    ]
    assert facts["links"] == [
        {
            "text": "Forgot password?",
            "href": "/forgot-password",
        }
    ]
    assert facts["forms"] == [
        {
            "id": "login-form",
        }
    ]
    assert facts["extraction_status"] == "success"
    assert facts["extraction_reason"] is None

def test_extract_browser_facts_with_nested_text():
    html = """
    <html>
        <body>
            <button id="save-button">
                <span>Save</span>
            </button>

            <a href="/account">
                <strong>My Account</strong>
            </a>
        </body>
    </html>
    """

    facts = extract_browser_facts(
        html=html,
        url="https://example.com",
    )

    assert facts["buttons"] == [
        {
            "text": "Save",
            "id": "save-button",
            "type": None,
        }
    ]

    assert facts["links"] == [
        {
            "text": "My Account",
            "href": "/account",
        }
    ]

def test_extract_browser_facts_builds_testable_elements():
    html = """
    <html>
        <body>
            <input
                id="username"
                name="username"
                data-testid="username-input"
                type="text"
            />

            <button
                id="login-button"
                aria-label="Sign in"
                type="submit"
            >
                Login
            </button>
        </body>
    </html>
    """

    facts = extract_browser_facts(
        html=html,
        url="https://example.com/login",
    )

    assert facts["testable_elements"] == [
        {
            "tag": "input",
            "id": "username",
            "name": "username",
            "data_testid": "username-input",
            "aria_label": None,
            "selectors": [
                '[data-testid="username-input"]',
                "#username",
                '[name="username"]',
            ],
        },
        {
            "tag": "button",
            "id": "login-button",
            "name": None,
            "data_testid": None,
            "aria_label": "Sign in",
            "selectors": [
                "#login-button",
                '[aria-label="Sign in"]',
            ],
        },
    ]

def test_extract_browser_facts_builds_selector_candidates():
    html = """
    <html>
        <body>
            <input
                id="username"
                name="username"
                data-testid="username-input"
                type="text"
            />

            <button
                id="login-button"
                aria-label="Sign in"
                type="submit"
            >
                Login
            </button>
        </body>
    </html>
    """

    facts = extract_browser_facts(
        html=html,
        url="https://example.com/login",
    )

    assert facts["testable_elements"][0]["selectors"] == [
        '[data-testid="username-input"]',
        "#username",
        '[name="username"]',
    ]

    assert facts["testable_elements"][1]["selectors"] == [
        "#login-button",
        '[aria-label="Sign in"]',
    ]

def test_extract_browser_facts_selector_fallback():
    html = """
    <html>
        <body>
            <button type="submit">
                Continue
            </button>
        </body>
    </html>
    """

    facts = extract_browser_facts(
        html=html,
        url="https://example.com",
    )

    assert facts["testable_elements"][0]["selectors"] == [
        'button[type="submit"]',
    ]

def test_extract_browser_facts_uses_button_text_as_selector_fallback():
    html = """
    <html>
        <body>
            <button>
                Continue
            </button>
        </body>
    </html>
    """

    facts = extract_browser_facts(
        html=html,
        url="https://example.com",
    )

    assert facts["testable_elements"][0]["selectors"] == [
        'text="Continue"',
    ]

def test_extract_browser_facts_uses_link_text_as_selector_fallback():
    html = """
    <html>
        <body>
            <a href="/account">
                My Account
            </a>
        </body>
    </html>
    """

    facts = extract_browser_facts(
        html=html,
        url="https://example.com",
    )

    assert facts["testable_elements"][0]["selectors"] == [
        'text="My Account"',
    ]

def test_extract_browser_facts_marks_navigable_links():
    html = """
    <html>
        <body>
            <a href="/account">Account</a>
            <a href="https://example.com/settings">Settings</a>
            <a href="#section">Section</a>
            <a href="javascript:void(0)">Action</a>
        </body>
    </html>
    """

    facts = extract_browser_facts(
        html=html,
        url="https://example.com/login",
    )

    assert facts["navigable_links"] == [
        "https://example.com/account",
        "https://example.com/settings",
    ]

def test_extract_browser_facts_resolves_relative_navigable_links():
    html = """
    <html>
        <body>
            <a href="/account">Account</a>
            <a href="settings">Settings</a>
        </body>
    </html>
    """

    facts = extract_browser_facts(
        html=html,
        url="https://example.com/login",
    )

    assert facts["navigable_links"] == [
        "https://example.com/account",
        "https://example.com/settings",
    ]

def test_extract_browser_facts_excludes_external_navigable_links():
    html = """
    <html>
        <body>
            <a href="/account">Account</a>
            <a href="https://example.com/settings">Settings</a>
            <a href="https://external.example.org/help">Help</a>
        </body>
    </html>
    """

    facts = extract_browser_facts(
        html=html,
        url="https://example.com/login",
    )

    assert facts["navigable_links"] == [
        "https://example.com/account",
        "https://example.com/settings",
    ]

def test_extract_browser_facts_deduplicates_navigable_links():
    html = """
    <html>
        <body>
            <a href="/account">Account</a>
            <a href="/account">My Account</a>
            <a href="https://example.com/account">Account Again</a>
        </body>
    </html>
    """

    facts = extract_browser_facts(
        html=html,
        url="https://example.com/login",
    )

    assert facts["navigable_links"] == [
        "https://example.com/account",
    ]

def test_extract_browser_facts_excludes_non_http_links():
    html = """
    <html>
        <body>
            <a href="/account">Account</a>
            <a href="mailto:test@example.com">Email</a>
            <a href="tel:+46123456789">Call</a>
        </body>
    </html>
    """

    facts = extract_browser_facts(
        html=html,
        url="https://example.com/login",
    )

    assert facts["navigable_links"] == [
        "https://example.com/account",
    ]

def test_extract_browser_facts_removes_url_fragments():
    html = """
    <html>
        <body>
            <a href="/account#profile">Profile</a>
            <a href="/account#security">Security</a>
        </body>
    </html>
    """

    facts = extract_browser_facts(
        html=html,
        url="https://example.com/login",
    )

    assert facts["navigable_links"] == [
        "https://example.com/account",
    ]